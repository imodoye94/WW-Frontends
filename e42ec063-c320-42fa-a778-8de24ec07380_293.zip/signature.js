const canvas = document.getElementById('signature-pad');
const ctx = canvas.getContext('2d');
const clearBtn = document.getElementById('clear-btn');
const saveBtn = document.getElementById('save-btn');
const toggleModeBtn = document.getElementById('toggle-mode-btn');
const typedSignature = document.getElementById('typed-signature');
const fontSelector = document.getElementById('font-selector');
const fontSizeSelector = document.getElementById('font-size-selector');
const selectors = document.getElementById('selectors');

let isDrawing = false;
let isTypedMode = false;

// Initialize a global object to store the base64 signatures
window.signatureData = {
  drawn: null,
  typed: null,
};

// Helper to get touch position
function getTouchPos(canvas, touchEvent) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: touchEvent.touches[0].clientX - rect.left,
    y: touchEvent.touches[0].clientY - rect.top,
  };
}

// Handle drawing events for mouse and touch
canvas.addEventListener('mousedown', (e) => {
  if (isTypedMode) return;
  isDrawing = true;
  ctx.beginPath();
  ctx.moveTo(e.offsetX, e.offsetY);
});

canvas.addEventListener('mousemove', (e) => {
  if (isDrawing && !isTypedMode) {
    ctx.lineTo(e.offsetX, e.offsetY);
    ctx.stroke();
  }
});

canvas.addEventListener('mouseup', () => (isDrawing = false));
canvas.addEventListener('mouseout', () => (isDrawing = false));

// Handle touch events
canvas.addEventListener('touchstart', (e) => {
  if (isTypedMode) return;
  isDrawing = true;
  const touchPos = getTouchPos(canvas, e);
  ctx.beginPath();
  ctx.moveTo(touchPos.x, touchPos.y);
});

canvas.addEventListener('touchmove', (e) => {
  if (isDrawing && !isTypedMode) {
    const touchPos = getTouchPos(canvas, e);
    ctx.lineTo(touchPos.x, touchPos.y);
    ctx.stroke();
  }
  e.preventDefault(); // Prevent scrolling while drawing
});

canvas.addEventListener('touchend', () => (isDrawing = false));

// Clear the canvas and typed signature
clearBtn.addEventListener('click', () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  typedSignature.value = '';
  window.signatureData.drawn = null; // Clear saved drawn signature
  window.signatureData.typed = null; // Clear saved typed signature
});

// Save the signature as a Base64 image
saveBtn.addEventListener('click', () => {
  if (isTypedMode) {
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = canvas.width;
    tempCanvas.height = canvas.height;
    const tempCtx = tempCanvas.getContext('2d');

    tempCtx.fillStyle = '#ffffff';
    tempCtx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);

    tempCtx.font = `${fontSizeSelector.value}px ${fontSelector.value}`;
    tempCtx.fillStyle = '#000000';
    tempCtx.textAlign = 'center';
    tempCtx.textBaseline = 'middle';
    tempCtx.fillText(typedSignature.value, tempCanvas.width / 2, tempCanvas.height / 2);

    window.signatureData.typed = tempCanvas.toDataURL('image/png');
    alert('Typed Signature saved!');
  } else {
    window.signatureData.drawn = canvas.toDataURL('image/png');
    alert('Drawn Signature saved!');
  }
});

// Toggle between drawing and typed signature modes
toggleModeBtn.addEventListener('click', () => {
  isTypedMode = !isTypedMode;
  canvas.style.display = isTypedMode ? 'none' : 'block';
  typedSignature.style.display = isTypedMode ? 'block' : 'none';
  selectors.style.display = isTypedMode ? 'block' : 'none';
  toggleModeBtn.textContent = isTypedMode ? 'Draw Signature' : 'Type Signature';

  if (!isTypedMode) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  } else {
    typedSignature.value = '';
    typedSignature.style.fontFamily = fontSelector.value;
    typedSignature.style.fontSize = `${fontSizeSelector.value}px`;
  }
});

// Update font style and size dynamically
fontSelector.addEventListener('change', () => {
  if (isTypedMode) {
    typedSignature.style.fontFamily = fontSelector.value;
  }
});

fontSizeSelector.addEventListener('change', () => {
  if (isTypedMode) {
    typedSignature.style.fontSize = `${fontSizeSelector.value}px`;
  }
});
