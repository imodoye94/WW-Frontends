/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["שני","שלישי","רביעי","חמישי","שישי","שבת","ראשון"],n=["ינואר","פברואר","מרץ","אפריל","מאי","יוני","יולי","אוגוסט","ספטמבר","אוקטובר","נובמבר","דצמבר"],o="שנים",e="שנה",s="חודש",c="שבוע",a="יום",d="היום",y="אין אירועים",r="כל היום",l="מחיקה",M="צור אירוע",Y="dddd D MMMM YYYY",h={weekDays:t,months:n,years:o,year:e,month:s,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:M,dateFormat:Y};export{r as allDay,M as createEvent,Y as dateFormat,a as day,h as default,l as deleteEvent,s as month,n as months,y as noEvent,d as today,c as week,t as weekDays,e as year,o as years};
