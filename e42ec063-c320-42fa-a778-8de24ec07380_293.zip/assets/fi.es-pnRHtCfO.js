/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const a=["Maanantai","Tiistai","Keskiviikko","Torstai","Perjantai","Lauantai","Sunnuntai"],t=["Tammikuu","Helmikuu","Maaliskuu","Huhtikuu","Toukokuu","Kesäkuu","Heinäkuu","Elokuu","Syyskuu","Lokakuu","Marraskuu","Joulukuu"],u="Vuodet",o="Vuosi",n="Kuukausi",s="Viikko",i="Päivä",e="Tänään",k="Ei tapahtumia",c="Koko päivä",d="Poista tapahtuma",m="Luo tapahtuma",r="dddd, D MMMM YYYY",l={weekDays:a,months:t,years:u,year:o,month:n,week:s,day:i,today:e,noEvent:k,allDay:c,deleteEvent:d,createEvent:m,dateFormat:r};export{c as allDay,m as createEvent,r as dateFormat,i as day,l as default,d as deleteEvent,n as month,t as months,k as noEvent,e as today,s as week,a as weekDays,o as year,u as years};
