/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["月","火","水","木","金","土","日"],n=["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"],o="年",s="今年",e="月",c="週",a="日",d="今日",y="イベントなし",r="終日",l="削除",M="イベント作成",Y="YYYY年 MMMM D日 (dddd)",m={weekDays:t,months:n,years:o,year:s,month:e,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:M,dateFormat:Y};export{r as allDay,M as createEvent,Y as dateFormat,a as day,m as default,l as deleteEvent,e as month,n as months,y as noEvent,d as today,c as week,t as weekDays,s as year,o as years};
