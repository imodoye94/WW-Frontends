/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const a=["Ponedeljak","Utorak","Sreda","Četvrtak","Petak","Subota","Nedelja"],e=["Januar","Februar","Mart","April","Maj","Jun","Jul","Avgust","Septembar","Oktobar","Novembar","Decembar"],t="Godine",o="Godina",n="Mesec",s="Sedmica",r="Dan",c="Danas",d="Nema događaja",l="Celi dan",i="Obriši",m="Kreiraj događaj",b="dddd D MMMM YYYY",k={weekDays:a,months:e,years:t,year:o,month:n,week:s,day:r,today:c,noEvent:d,allDay:l,deleteEvent:i,createEvent:m,dateFormat:b};export{l as allDay,m as createEvent,b as dateFormat,r as day,k as default,i as deleteEvent,n as month,e as months,d as noEvent,c as today,s as week,a as weekDays,o as year,t as years};
