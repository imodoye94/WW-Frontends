/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Dilluns","Dimarts","Dimecres","Dijous","Divendres","Dissabte","Diumenge"],t=["Dl","Dt","Dc","Dj","Dv","Ds","Dg"],n=["Gener","Febrer","Març","Abril","Maig","Juny","Juliol","Agost","Setembre","Octubre","Novembre","Desembre"],s="Anys",o="Any",a="Mes",r="Setmana",c="Dia",D="Avui",i="No hi ha esdeveniments",d="Tot el dia",m="Eliminar",l="Crear un esdeveniment",y="dddd D MMMM YYYY",u={weekDays:e,weekDaysShort:t,months:n,years:s,year:o,month:a,week:r,day:c,today:D,noEvent:i,allDay:d,deleteEvent:m,createEvent:l,dateFormat:y};export{d as allDay,l as createEvent,y as dateFormat,c as day,u as default,m as deleteEvent,a as month,n as months,i as noEvent,D as today,r as week,e as weekDays,t as weekDaysShort,o as year,s as years};
