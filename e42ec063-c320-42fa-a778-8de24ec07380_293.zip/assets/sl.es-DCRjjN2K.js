/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Ponedeljek","Torek","Sreda","Četrtek","Petek","Sobota","Nedelja"],t=["Januar","Februar","Marec","April","Maj","Junij","Julij","Avgust","September","Oktober","November","December"],o="Leta",n="Leto",a="Mesec",s="Teden",d="Dan",r="Danes",c="Ni dogodkov",l="Cel dan",k="Odstrani",v="Ustvari dogodek",M="dddd MMMM D, YYYY",b={weekDays:e,months:t,years:o,year:n,month:a,week:s,day:d,today:r,noEvent:c,allDay:l,deleteEvent:k,createEvent:v,dateFormat:M};export{l as allDay,v as createEvent,M as dateFormat,d as day,b as default,k as deleteEvent,a as month,t as months,c as noEvent,r as today,s as week,e as weekDays,n as year,o as years};
