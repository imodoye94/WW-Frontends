/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Pondělí","Úterý","Středa","Čtvrtek","Pátek","Sobota","Neděle"],t=["Leden","Únor","Březen","Duben","Květen","Červen","Červenec","Srpen","Září","Říjen","Listopad","Prosinec"],n="Roky",o="Rok",s="Měsíc",c="Týden",d="Den",a="Dnes",r="Bez událostí",l="Celý den",v="Odstranit",y="Vytvořit událost",k="dddd D. MMMM YYYY",D={weekDays:e,months:t,years:n,year:o,month:s,week:c,day:d,today:a,noEvent:r,allDay:l,deleteEvent:v,createEvent:y,dateFormat:k};export{l as allDay,y as createEvent,k as dateFormat,d as day,D as default,v as deleteEvent,s as month,t as months,r as noEvent,a as today,c as week,e as weekDays,o as year,n as years};
