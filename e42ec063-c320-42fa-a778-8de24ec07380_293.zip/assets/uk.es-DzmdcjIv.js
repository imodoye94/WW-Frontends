/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["Понеділок","Вівторок","Середа","Четвер","П'ятниця","Субота","Неділя"],o=["Січень","Лютий","Березень","Квітень","Травень","Червень","Липень","Серпень","Вересень","Жовтень","Листопад","Грудень"],n=["Пн","Вт","Ср","Чт","Пт","Сб","Нд"],s="Роки",e="Рік",c="Місяць",a="Тиждень",d="День",y="Сьогодні",r="Немає подій",k="Весь день",l="Видалити",D="Створити подію",M="dddd D MMMM YYYY",Y={weekDays:t,months:o,weekDaysShort:n,years:s,year:e,month:c,week:a,day:d,today:y,noEvent:r,allDay:k,deleteEvent:l,createEvent:D,dateFormat:M};export{k as allDay,D as createEvent,M as dateFormat,d as day,Y as default,l as deleteEvent,c as month,o as months,r as noEvent,y as today,a as week,t as weekDays,n as weekDaysShort,e as year,s as years};
