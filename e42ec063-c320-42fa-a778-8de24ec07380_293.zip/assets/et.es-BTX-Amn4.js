/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Esmaspäev","Teisipäev","Kolmapäev","Neljapäev","Reede","Laupäev","Pühapäev"],t=["Jaanuar","Veebruar","Märts","Aprill","Mai","Juuni","Juuli","August","September","Oktoober","November","Detsember"],s="Aastad",a="Aasta",o="Kuu",n="Nädal",u="Päev",c="Täna",d="Sündmus puudub",r="Terve päev",v="Kustuta",p="Loo sündmus",l="dddd D MMMM YYYY",m={weekDays:e,months:t,years:s,year:a,month:o,week:n,day:u,today:c,noEvent:d,allDay:r,deleteEvent:v,createEvent:p,dateFormat:l};export{r as allDay,p as createEvent,l as dateFormat,u as day,m as default,v as deleteEvent,o as month,t as months,d as noEvent,c as today,n as week,e as weekDays,a as year,s as years};
