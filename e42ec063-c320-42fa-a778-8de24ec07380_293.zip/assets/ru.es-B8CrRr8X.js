/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"],o=["Пн","Вт","Ср","Чт","Пт","Сб","Вс"],n=["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],s="Годы",e="Год",c="Месяц",a="Неделя",d="День",r="Сегодня",y="Нет событий",l="Весь день",D="Удалить",M="Создать событие",Y="dddd D MMMM YYYY",h={weekDays:t,weekDaysShort:o,months:n,years:s,year:e,month:c,week:a,day:d,today:r,noEvent:y,allDay:l,deleteEvent:D,createEvent:M,dateFormat:Y};export{l as allDay,M as createEvent,Y as dateFormat,d as day,h as default,D as deleteEvent,c as month,n as months,y as noEvent,r as today,a as week,t as weekDays,o as weekDaysShort,e as year,s as years};
