/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag","Søndag"],t=["Januar","Februar","Marts","April","Maj","Juni","Juli","August","September","Oktober","November","December"],n="År (flertal)",a="År",o="Måned",s="Uge",r="Dag",d="I dag",c="Ingen begivenhed",g="Hele dagen",l="Slet",M="Opret et event",u="dddd D MMMM YYYY",b={weekDays:e,months:t,years:n,year:a,month:o,week:s,day:r,today:d,noEvent:c,allDay:g,deleteEvent:l,createEvent:M,dateFormat:u};export{g as allDay,M as createEvent,u as dateFormat,r as day,b as default,l as deleteEvent,o as month,t as months,c as noEvent,d as today,s as week,e as weekDays,a as year,n as years};
