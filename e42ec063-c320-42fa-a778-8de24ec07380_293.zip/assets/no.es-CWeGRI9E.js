/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Mandag","Tirsdag","Onsdag","Torsdag","Fredag","Lørdag","Søndag"],n=["Januar","Februar","Mars","April","Mai","Juni","Juli","August","September","Oktober","November","Desember"],t="Velg år",a="År",s="Måned",o="Uke",d="Dag",r="Idag",c="Ingen hendelse",g="Hele dagen",l="Ta bort",M="Ny hendelse",u="dddd, D. MMMM YYYY",y={weekDays:e,months:n,years:t,year:a,month:s,week:o,day:d,today:r,noEvent:c,allDay:g,deleteEvent:l,createEvent:M,dateFormat:u};export{g as allDay,M as createEvent,u as dateFormat,d as day,y as default,l as deleteEvent,s as month,n as months,c as noEvent,r as today,o as week,e as weekDays,a as year,t as years};
