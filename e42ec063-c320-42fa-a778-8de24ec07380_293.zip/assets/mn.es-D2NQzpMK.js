/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["Даваа","Мягмар","Лхавга","Пүрэв","Баасан","Бямба","Ням"],n=["1-р сар","2-р сар","3-р сар","4-р сар","5-р сар","6-р сар","7-р сар","8-р сар","9-р сар","10-р сар","11-р сар","12-р сар"],o="Жилүүд",s="Жил",e="Сар",c="Долоо хоног",a="Өдөр",d="Өнөөдөр",y="Тэмдэглэлгүй",r="Бүх өдөр",l="Устгах",m="Шинэ тэмдэглэл",M="dddd D MMMM YYYY",Y={weekDays:t,months:n,years:o,year:s,month:e,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:m,dateFormat:M};export{r as allDay,m as createEvent,M as dateFormat,a as day,Y as default,l as deleteEvent,e as month,n as months,y as noEvent,d as today,c as week,t as weekDays,s as year,o as years};
