/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const a=["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"],n=["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"],e="Tahunan",t="Tahun",s="Bulan",o="Minggu",i="Hari",r="Hari Ini",u="Tidak Ada Kegiatan",c="Sepanjang Hari",d="Hapus",m="Tambah Kegiatan",b="dddd, D MMMM YYYY",g={weekDays:a,months:n,years:e,year:t,month:s,week:o,day:i,today:r,noEvent:u,allDay:c,deleteEvent:d,createEvent:m,dateFormat:b};export{c as allDay,m as createEvent,b as dateFormat,i as day,g as default,d as deleteEvent,s as month,n as months,u as noEvent,r as today,o as week,a as weekDays,t as year,e as years};
