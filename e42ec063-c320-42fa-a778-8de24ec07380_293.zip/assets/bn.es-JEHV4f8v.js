/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["সোম","মঙ্গল","বুধ","বৃহস্পতি","শুক্র","শনি","রবি"],n=["জানুয়ারি","ফেব্ুয়ারী","মার্চ","এপ্রিল","মে","জুন","জুলাই","অগাস্ট","সেপ্টেম্বর","অক্টোবর","নভেম্বর","ডিসেম্বর"],o="বছর",s="বছর",e="মাস",c="সপ্তাহ",a="দিন",d="আজ",y="কার্যসূচী",r="সারাদিন",l="মুছুন",M="কার্যসূচী তৈরি করুন",Y="dddd D MMMM YYYY",m={weekDays:t,months:n,years:o,year:s,month:e,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:M,dateFormat:Y};export{r as allDay,M as createEvent,Y as dateFormat,a as day,m as default,l as deleteEvent,e as month,n as months,y as noEvent,d as today,c as week,t as weekDays,s as year,o as years};
