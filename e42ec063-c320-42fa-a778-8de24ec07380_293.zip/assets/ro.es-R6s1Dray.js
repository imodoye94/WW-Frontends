/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Luni","Marți","Miercuri","Joi","Vineri","Sâmbăta","Duminică"],t=["Ianuarie","Februarie","Martie","Aprilie","Mai","Iunie","Iulie","August","Septembrie","Octombrie","Noiembrie","Decembrie"],n="Ani",i="An",o="Lună",a="Săptămână",c="Zi",r="Azi",s="Nici o interacțiune",u="Toată ziua",m="Șterge",d="Adaugă un eveniment",M="dddd D MMMM YYYY",b={weekDays:e,months:t,years:n,year:i,month:o,week:a,day:c,today:r,noEvent:s,allDay:u,deleteEvent:m,createEvent:d,dateFormat:M};export{u as allDay,d as createEvent,M as dateFormat,c as day,b as default,m as deleteEvent,o as month,t as months,s as noEvent,r as today,a as week,e as weekDays,i as year,n as years};
