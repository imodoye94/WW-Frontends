/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["E Hënë","E Martë","E Mërkurë","E Enjte","E Premte","E Shtunë","E Diel"],e=["Hë","Ma","Mr","Enj","Pr","Sh","D"],n=["Janar","Shkurt","Mars","Prill","Maj","Qershor","Korrik","Gusht","Shtator","Tetor","Nëntor","Dhjetor"],o="Vitet",r="Viti",a="Muaji",s="Java",c="Dita",E="Sot",h="Nuk ka event",i="Tërë ditën",M="Fshijë",d="Krijo një event",j="dddd D MMMM YYYY",k={weekDays:t,weekDaysShort:e,months:n,years:o,year:r,month:a,week:s,day:c,today:E,noEvent:h,allDay:i,deleteEvent:M,createEvent:d,dateFormat:j};export{i as allDay,d as createEvent,j as dateFormat,c as day,k as default,M as deleteEvent,a as month,n as months,h as noEvent,E as today,s as week,t as weekDays,e as weekDaysShort,r as year,o as years};
