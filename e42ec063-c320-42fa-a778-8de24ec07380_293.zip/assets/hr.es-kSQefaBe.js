/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const a=["Ponedjeljak","Utorak","Srijeda","Četvrtak","Petak","Subota","Nedjelja"],n=["Siječanj","Veljača","Ožujak","Travanj","Svibanj","Lipanj","Srpanj","Kolovoz","Rujan","Listopad","Studeni","Prosinac"],e="Godine",t="Godina",o="Mjesec",d="Tjedan",j="Dan",s="Današnji dan",c="Nema događaja",i="Cijeli dan",r="Obriši",l="Kreiraj događaj",k="dddd D MMMM YYYY",v={weekDays:a,months:n,years:e,year:t,month:o,week:d,day:j,today:s,noEvent:c,allDay:i,deleteEvent:r,createEvent:l,dateFormat:k};export{i as allDay,l as createEvent,k as dateFormat,j as day,v as default,r as deleteEvent,o as month,n as months,c as noEvent,s as today,d as week,a as weekDays,t as year,e as years};
