/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const a=["Mánudagur","Þriðjudagur","Miðvikudagur","Fimmtudagur","Föstudagur","Laugardagur","Sunnudagur"],t=["Janúar","Febrúar","Mars","Apríl","Maí","Júní","Júlí","Ágúst","September","Október","Nóvember","Desember"],n="Ár",r="Ár",e="Mánuður",s="Vika",u="Dagur",o="Í dag",d="Enginn atburður",c="Allan daginn",g="Eyða",i="Búðu til viðburð",l="dddd D MMMM YYYY",M={weekDays:a,months:t,years:n,year:r,month:e,week:s,day:u,today:o,noEvent:d,allDay:c,deleteEvent:g,createEvent:i,dateFormat:l};export{c as allDay,i as createEvent,l as dateFormat,u as day,M as default,g as deleteEvent,e as month,t as months,d as noEvent,o as today,s as week,a as weekDays,r as year,n as years};
