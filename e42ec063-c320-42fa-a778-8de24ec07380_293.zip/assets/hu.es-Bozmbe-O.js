/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Hétfo","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"],t=["Január","Február","Március","Április","Május","Június","Július","Augusztus","Szeptember","Október","November","December"],s="Évek",n="Év",o="Hónap",a="Hét",r="Nap",c="Mai nap",d="Nincs esemény",u="Egész nap",m="Esemény törlese",y="Esemény létrehozása",l="dddd D MMMM YYYY",p={weekDays:e,months:t,years:s,year:n,month:o,week:a,day:r,today:c,noEvent:d,allDay:u,deleteEvent:m,createEvent:y,dateFormat:l};export{u as allDay,y as createEvent,l as dateFormat,r as day,p as default,m as deleteEvent,o as month,t as months,d as noEvent,c as today,a as week,e as weekDays,n as year,s as years};
