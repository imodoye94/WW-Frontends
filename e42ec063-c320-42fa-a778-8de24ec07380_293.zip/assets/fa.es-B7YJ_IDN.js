/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["دوشنبه","سه شنبه","چهار شنبه","پنج شنبه","جمعه","شنبه","یک شنبه"],n=["ژانویه","فوریه","مارس","آوریل","می","ژوئن","ژوئیه","اوت","سپتامبر","اکتبر","نوامبر","دسامبر"],o="سالها",s="سال",e="ماه",c="هفته",a="روز",d="امروز",y="رویدادی نیست",r="تمام روز",l="حذف",M="ایجاد یک رویداد",Y="dddd D MMMM YYYY",m={weekDays:t,months:n,years:o,year:s,month:e,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:M,dateFormat:Y};export{r as allDay,M as createEvent,Y as dateFormat,a as day,m as default,l as deleteEvent,e as month,n as months,y as noEvent,d as today,c as week,t as weekDays,s as year,o as years};
