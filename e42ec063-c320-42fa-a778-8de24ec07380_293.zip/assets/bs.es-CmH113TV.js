/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const a=["Ponedjeljak","Utorak","Srijeda","Četvrtak","Petak","Subota","Nedjelja"],e=["Januar","Februar","Mart","April","Maj","Jun","Jul","Avgust","Septembar","Oktobar","Novembar","Decembar"],t="Godine",o="Godina",n="Mjesec",s="Sedmica",r="Dan",c="Danas",d="Nema događaja",j="Cijeli dan",i="Obriši",l="Kreiraj događaj",b="dddd D MMMM YYYY",m={weekDays:a,months:e,years:t,year:o,month:n,week:s,day:r,today:c,noEvent:d,allDay:j,deleteEvent:i,createEvent:l,dateFormat:b};export{j as allDay,l as createEvent,b as dateFormat,r as day,m as default,i as deleteEvent,n as month,e as months,d as noEvent,c as today,s as week,a as weekDays,o as year,t as years};
