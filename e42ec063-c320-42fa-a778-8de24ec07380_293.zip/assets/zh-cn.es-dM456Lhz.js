/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["星期一","星期二","星期三","星期四","星期五","星期六","星期日"],n=["一","二","三","四","五","六","日"],o=["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"],s="年",e="本年",c="月",a="周",d="日",y="今日",r="暂无活动",h="整天",l="删除",D="新建活动",M="YYYY MMMM D dddd",Y={weekDays:t,weekDaysShort:n,months:o,years:s,year:e,month:c,week:a,day:d,today:y,noEvent:r,allDay:h,deleteEvent:l,createEvent:D,dateFormat:M};export{h as allDay,D as createEvent,M as dateFormat,d as day,Y as default,l as deleteEvent,c as month,o as months,r as noEvent,y as today,a as week,t as weekDays,n as weekDaysShort,e as year,s as years};
