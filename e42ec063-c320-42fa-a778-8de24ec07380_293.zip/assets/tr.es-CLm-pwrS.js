/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"],a=["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"],n="Yıllar",e="Yıl",s="Ay",o="Hafta",c="Gün",l="Bugün",r="Etkinlik Yok",m="Tüm gün",k="Sil",i="Etkinlik ekle",d="dddd D MMMM YYYY",y={weekDays:t,months:a,years:n,year:e,month:s,week:o,day:c,today:l,noEvent:r,allDay:m,deleteEvent:k,createEvent:i,dateFormat:d};export{m as allDay,i as createEvent,d as dateFormat,c as day,y as default,k as deleteEvent,s as month,a as months,r as noEvent,l as today,o as week,t as weekDays,e as year,n as years};
