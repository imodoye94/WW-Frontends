/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Poniedziałek","Wtorek","Środa","Czwartek","Piątek","Sobota","Niedziela"],t=["Styczeń","Luty","Marzec","Kwiecień","Maj","Czerwiec","Lipiec","Sierpień","Wrzesień","Październik","Listopad","Grudzień"],a="Lata",o="Rok",i="Miesiąc",n="Tydzień",s="Dzień",c="Dzisiaj",d="Brak wydarzeń",r="Cały dzień",z="Usuń",y="Utwórz wydarzenie",k="dddd, D MMMM YYYY",w={weekDays:e,months:t,years:a,year:o,month:i,week:n,day:s,today:c,noEvent:d,allDay:r,deleteEvent:z,createEvent:y,dateFormat:k};export{r as allDay,y as createEvent,k as dateFormat,s as day,w as default,z as deleteEvent,i as month,t as months,d as noEvent,c as today,n as week,e as weekDays,o as year,a as years};
