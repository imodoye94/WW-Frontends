/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const n=["Thứ hai","Thứ ba","Thứ tư","Thứ năm","Thứ sáu","Thứ bảy","Chủ nhật"],t=["T2","T3","T4","T5","T6","T7","CN"],T=["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5","Tháng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Tháng 12"],h="Năm",o="Năm nay",e="Tháng",s="Tuần",a="Ngày",c="Hôm nay",g="NKhông có Event",y="Cả ngày",d="Xóa",m="Tạo event",r="dddd MMMM D YYYY",v={weekDays:n,weekDaysShort:t,months:T,years:h,year:o,month:e,week:s,day:a,today:c,noEvent:g,allDay:y,deleteEvent:d,createEvent:m,dateFormat:r};export{y as allDay,m as createEvent,r as dateFormat,a as day,v as default,d as deleteEvent,e as month,T as months,g as noEvent,c as today,s as week,n as weekDays,t as weekDaysShort,o as year,h as years};
