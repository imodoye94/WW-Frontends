/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["월","화","수","목","금","토","일"],o=["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"],n="년도",s="연간",e="월간",c="주간",a="일간",d="오늘",y="일정 없음",r="하루 종일",l="삭제",M="일정 추가",Y="YYYY년 MMMM D일 dddd요일",k={weekDays:t,months:o,years:n,year:s,month:e,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:M,dateFormat:Y};export{r as allDay,M as createEvent,Y as dateFormat,a as day,k as default,l as deleteEvent,e as month,o as months,y as noEvent,d as today,c as week,t as weekDays,s as year,n as years};
