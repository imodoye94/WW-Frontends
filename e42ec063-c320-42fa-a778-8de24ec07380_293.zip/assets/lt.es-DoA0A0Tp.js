/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const i=["Pirmadienis","Antradienis","Trečiadienis","Ketvirtadienis","Penktadienis","Šeštadienis","Sekmadienis"],s=["Sausis","Vasaris","Kovas","Balandis","Gegužė","Birželis","Liepa","Rugpjūtis","Rugsėjis","Spalis","Lapkritis","Gruodis"],t="Metų pasirinkimas",e="Metai",a="Mėnesis",n="Savaitė",o="Diena",d="Šiandien",r="Jokių įvykių",c="Visa diena",k="Ištrinti",l="Sukurti įvykį",u="dddd, D MMMM YYYY",v={weekDays:i,months:s,years:t,year:e,month:a,week:n,day:o,today:d,noEvent:r,allDay:c,deleteEvent:k,createEvent:l,dateFormat:u};export{c as allDay,l as createEvent,u as dateFormat,o as day,v as default,k as deleteEvent,a as month,s as months,r as noEvent,d as today,n as week,i as weekDays,e as year,t as years};
