/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const t=["Понеделник","Вторник","Сряда","Четвъртък","Петък","Събота","Неделя"],n=["Януари","Февруари","Март","Април","Май","Юни","Юли","Август","Септември","Октомври","Ноември","Декември"],o="Години",s="Година",e="Месец",c="Седмица",a="Ден",d="Днес",y="Няма събития",r="Цял ден",l="Изтрий",M="Създай събитие",Y="dddd D MMMM YYYY",m={weekDays:t,months:n,years:o,year:s,month:e,week:c,day:a,today:d,noEvent:y,allDay:r,deleteEvent:l,createEvent:M,dateFormat:Y};export{r as allDay,M as createEvent,Y as dateFormat,a as day,m as default,l as deleteEvent,e as month,n as months,y as noEvent,d as today,c as week,t as weekDays,s as year,o as years};
