/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Pondelok","Utorok","Streda","Štvrtok","Piatok","Sobota","Nedeľa"],t=["Január","Február","Marec","Apríl","Máj","Jún","Júl","August","September","Október","November","December"],o="Roky",n="Rok",s="Mesiac",a="Týždeň",r="Deň",c="Dnes",d="Bez udalosti",k="Celý deň",l="Odstrániť",y="Vytvoriť udalosť",u="dddd D. MMMM YYYY",M={weekDays:e,months:t,years:o,year:n,month:s,week:a,day:r,today:c,noEvent:d,allDay:k,deleteEvent:l,createEvent:y,dateFormat:u};export{k as allDay,y as createEvent,u as dateFormat,r as day,M as default,l as deleteEvent,s as month,t as months,d as noEvent,c as today,a as week,e as weekDays,n as year,o as years};
