/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Måndag","Tisdag","Onsdag","Torsdag","Fredag","Lördag","Söndag"],a=["Januari","Februari","Mars","April","Maj","Juni","Juli","Augusti","September","Oktober","November","December"],n="År",t="År",s="Månad",o="Vecka",d="Dag",r="Idag",c="Ingen händelse",g="Heldag",l="Ta bort",M="Skapa händelse",i="dddd den D MMMM YYYY",u={weekDays:e,months:a,years:n,year:t,month:s,week:o,day:d,today:r,noEvent:c,allDay:g,deleteEvent:l,createEvent:M,dateFormat:i};export{g as allDay,M as createEvent,i as dateFormat,d as day,u as default,l as deleteEvent,s as month,a as months,c as noEvent,r as today,o as week,e as weekDays,t as year,n as years};
