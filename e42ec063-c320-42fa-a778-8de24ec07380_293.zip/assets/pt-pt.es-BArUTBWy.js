/**
  * vue-cal v4.10.0
  * (c) 2024 Antoni Andre <antoniandre.web@gmail.com>
  * @license MIT
  */const e=["Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado","Domingo"],o=["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"],t="Anos",a="Ano",n="Mês",r="Semana",s="Dia",i="Hoje",c="Sem eventos",d="Dia inteiro",m="Remover",u="Criar um evento",v="dddd D MMMM YYYY",D={weekDays:e,months:o,years:t,year:a,month:n,week:r,day:s,today:i,noEvent:c,allDay:d,deleteEvent:m,createEvent:u,dateFormat:v};export{d as allDay,u as createEvent,v as dateFormat,s as day,D as default,m as deleteEvent,n as month,o as months,c as noEvent,i as today,r as week,e as weekDays,a as year,t as years};
